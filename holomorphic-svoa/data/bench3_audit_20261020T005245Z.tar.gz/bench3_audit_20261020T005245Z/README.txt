Benchmark-v3 audit bundle 20261020T005245Z (UTC), frozen by tools/cpu_table.py from one reconciled snapshot of every
lane folder claude/persistent/bench3_*: state.json (counters), runs.jsonl (seed, argv, Python/numpy
versions, SHA-256 of the worker sources; local workspace path replaced by <workspace>), epochs.jsonl (pool
RNG states), hit_index.jsonl (one line per exact closure hit), rowspaces.txt (distinct RREF rowspace hashes)
and hits.jsonl (the stored full hit records with generators and verification reports). The table on
index.html is recounted from this bundle; code/bench_v3/ has the worker sources named in runs.jsonl.
Publication copy (20 October 2026): the process-ID fields ("pid") were removed from the JSON records
(state.json, runs.jsonl); nothing else was changed, timestamps included.
